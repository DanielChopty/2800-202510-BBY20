# 2800-202510-BBY20

## About Us
Team Name: BBY-20
Team Members: 
- Jayden Bergstrome
- Daniel Chopty
- Mykyta Bozhanov
- Jun Morimoto
- Baltaj Bhandal
## More details to come
TBA